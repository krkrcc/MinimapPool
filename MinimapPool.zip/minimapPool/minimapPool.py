# -*- coding: utf-8 -*-
# @Author  : krkrcc
# ------------------------------
import os
import time
import numpy as np
from mpi4py import MPI


def split_large_file(readslist, output_folder, num_files=64):
    readslength = len(readslist)
    count = 0
    path = ""
    pathlist = []
    for i in range(num_files):
        tmp = count
        tempreads = []
        for reads in readslist[tmp:int(readslength / num_files) + tmp]:
            tempreads.append(reads)
            count += 1
        if i == num_files - 1:
            for reads in readslist[count:]:
                tempreads.append(reads)
        path = output_folder + str(i) + ".fa"
        file = open(path, "w", -1)
        for lines in tempreads:
            file.write(lines)
            file.write("\n")
        file.close()
        pathlist.append(path)
    return pathlist

def main():
    start = time.time()
    comm = MPI.COMM_WORLD
    rank = comm.Get_rank()
    size = comm.Get_size()

    result_folder = '/home/minimapPool/result/'
    output_folder = '/home/minimapPool/tmp_fa/'
    c_executable = '/home/minimap2/minimap2'
    num_processes = size
    task_pool = []
    if rank == 0:
        readslist = fileoperation.fileload(sys.argv[1])
        print("The main process starts creating a task pool")
        task_pool = split_large_file(readslist, output_folder)
        print("The main process creates the task pool ends")
        available_pro = [i + 1 for i in range(size - 1)]
        while len(task_pool) > 0:
            if len(available_pro) > 0:
                pro_num = available_pro.pop(0)
                file_to_process = task_pool.pop(0)
                print(f"Assign the {file_to_process} to process {pro_num}")
                comm.send(file_to_process, pro_num)
            else:
                status = MPI.Status()
                message = comm.recv(source=MPI.ANY_SOURCE, status=status)
                source_rank = status.Get_source()
                available_pro.append(source_rank)
                print(f"{source_rank}  over!")
        while len(available_pro) < size - 1:
            status = MPI.Status()
            comm.recv(source=MPI.ANY_SOURCE)
            source_rank = status.Get_source()
            available_pro.append(source_rank)
        for i in range(size - 1):
            comm.send('-1', i + 1)
    else:
        while True:
            file_to_process = comm.recv(source=0)
            if file_to_process == '-1':
                break
            print(f"Process {rank} is processing {file_to_process}")
            file_name, _ = os.path.splitext(os.path.basename(file_to_process))
            command = [
                c_executable, '-a', '-t', '1', '/home/ref/ref.fa', file_to_process
            ]
            # ִ������
            try:
                p = subprocess.run(command, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
                savepath = result_folder + file_name + ".sam"
                if os.path.exists(savepath):
                    os.remove(savepath)
                file = open(savepath, "w")
                tmp = 0
                result = []
                for line in p.stdout.splitlines():
                    if line.strip() == "minimap_is_finished":
                        break
                    deline = line.strip()
                    if (deline[0] != '@'):
                        result.append(deline)
                        tmp += 1
                    if (tmp == 5000):
                        for lines in result:
                            file.write(lines)
                            file.write("\n")
                        tmp = 0
                        result.clear()
                if (tmp != 0):
                    for lines in result:
                        file.write(lines)
                        file.write("\n")
                    tmp = 0
                    result.clear()
                file.close()
                comm.send("1", dest=0)
                print(f"Process {rank} is process {file_to_process} over!")
            except subprocess.CalledProcessError as e:
                print(f"Error while running command: {e}")

    comm.Barrier()
    if rank == 0:
        print("Results are being consolidated!")
        input_folder = '/home/minimapPool/result/'
        output_file = '/home/minimapPool/result/result.sam'
        print(f"The results are saved in the {output_file}")
        concatenate_files(input_folder, output_file)
        tmp_time = str(time.time() - start)
        print("MinimapPool with " + str(size) + " cores,time use: " + tmp_time)
        file_path = "./output/new/1.txt"
        with open(file_path, mode='w', encoding='utf-8') as file_obj:
            file_obj.write("MinimapPool " + str(size) + " cores,time use: " + tmp_time)
    comm.Barrier()
    MPI.Finalize()

if __name__ == "__main__":
    main()
